package com.example.archibook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchibookApplicationTests {

    @Test
    void contextLoads() {
    }

}
